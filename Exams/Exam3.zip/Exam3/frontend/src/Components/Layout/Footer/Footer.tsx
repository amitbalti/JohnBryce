import "./Footer.css";

function Footer(): JSX.Element {
  return (
    <div className="Footer">
      <h3>All rights reseved &copy; to Amit Balteriski</h3>
    </div>
  );
}

export default Footer;
