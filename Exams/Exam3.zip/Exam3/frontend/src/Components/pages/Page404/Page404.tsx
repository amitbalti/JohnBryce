import "./Page404.css";

function Page404(): JSX.Element {
  return (
    <div className="Page404">
      <h1>Oops... You reached a dead end...</h1>
    </div>
  );
}

export default Page404;
