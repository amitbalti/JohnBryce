class DevGroup {
  public id: number;
  public groupName: string;

  constructor(id: number, groupName: string) {
    this.id = id;
    this.groupName = groupName;
  }
}

export default DevGroup;
