class ProductModel {
    public id: number;
    public name: string;
    public price: number;
    public stock: number;
}

export default ProductModel;