class AppConfig {
    private baseUrl = process.env.REACT_APP_BACKEND_BASE_URL || "http://localhost:5000/api/";
    public productsUrl = this.baseUrl + "products/";
}

const appConfig = new AppConfig();

export default appConfig;