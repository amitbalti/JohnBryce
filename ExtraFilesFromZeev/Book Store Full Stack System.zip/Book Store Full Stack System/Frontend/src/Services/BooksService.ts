import axios from "axios";
import BookModel from "../Models/BookModel";
import GenreModel from "../Models/GenreModel";
import appConfig from "../Utils/Config";

class BooksService {

    public async getAllBooks(): Promise<BookModel[]> {
        const response = await axios.get<BookModel[]>(appConfig.booksUrl);
        const books = response.data;
        return books;
    }

    public async getAllGenres(): Promise<GenreModel[]> {
        const response = await axios.get<GenreModel[]>(appConfig.genresUrl);
        const genres = response.data;
        return genres;
    }

    public async addBook(book: BookModel): Promise<void> {
        const response = await axios.post<BookModel>(appConfig.booksUrl, book);
        const addedBook = response.data;
        // If we have Redux, we shall send addedBook via dispatch
    }

    public async deleteBook(bookId: number): Promise<void> {
        await axios.delete(appConfig.booksUrl + bookId);
    }

}

const booksService = new BooksService();

export default booksService;
