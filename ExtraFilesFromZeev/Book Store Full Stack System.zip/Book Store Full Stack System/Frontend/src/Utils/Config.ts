class Config {
    public genresUrl = "http://localhost:3001/api/genres/";
    public booksUrl = "http://localhost:3001/api/books/";
}

const appConfig = new Config();

export default appConfig;
