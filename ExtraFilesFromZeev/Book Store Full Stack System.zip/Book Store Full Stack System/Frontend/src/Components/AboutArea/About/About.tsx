import "./About.css";

function About(): JSX.Element {
    return (
        <div className="About">
			<h2>About Page</h2>
        </div>
    );
}

export default About;
