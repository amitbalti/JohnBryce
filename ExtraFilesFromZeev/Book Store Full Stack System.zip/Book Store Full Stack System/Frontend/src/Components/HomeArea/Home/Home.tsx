import "./Home.css";

function Home(): JSX.Element {
    return (
        <div className="Home">
			<h2>Home Page</h2>
        </div>
    );
}

export default Home;
