import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import BookModel from "../../../Models/BookModel";
import GenreModel from "../../../Models/GenreModel";
import booksService from "../../../Services/BooksService";
import "./AddBook.css";

function AddBook(): JSX.Element {

    const [genres, setGenres] = useState<GenreModel[]>([]);
    const { register, handleSubmit } = useForm<BookModel>();
    const navigate = useNavigate();

    useEffect(() => {
        booksService.getAllGenres()
            .then(genres => setGenres(genres))
            .catch(err => alert(err.message));
    }, []);

    async function send(book: BookModel) {
        try {
            await booksService.addBook(book);
            alert("Book has been added.");
            navigate("/books");
        }
        catch (err: any) {
            alert(err.message);
        }
    }

    return (
        <div className="AddBook">

            <form onSubmit={handleSubmit(send)}>

                <h2>Add Book</h2>

                <label>Name: </label>
                <input type="text" {...register("bookName")} />

                <label>Summary: </label>
                <input type="text" {...register("summary")} />

                <label>Genre: </label>
                <select defaultValue="" {...register("genreId")}>
                    <option disabled value="">Select Genre...</option>
                    {genres.map(g => <option key={g.genreId} value={g.genreId}>{g.genreName}</option>)}
                </select>

                <label>Price: </label>
                <input type="number" {...register("price")} />

                <label>Stock: </label>
                <input type="number" {...register("stock")} />

                <button>Add</button>

            </form>
        </div>
    );
}

export default AddBook;
