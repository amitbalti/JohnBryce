import { SyntheticEvent, useEffect, useState } from "react";
import BookModel from "../../../Models/BookModel";
import booksService from "../../../Services/BooksService";
import "./BookList.css";

function BookList(): JSX.Element {

    const [books, setBooks] = useState<BookModel[]>([]);

    useEffect(() => {
        booksService.getAllBooks()
            .then(books => setBooks(books))
            .catch(err => alert(err.message));
    }, []);

    async function deleteBook(bookId: number) {
        try {
            await booksService.deleteBook(bookId);
            alert("Book has been deleted!");
            // rerender the UI...
        }
        catch (err: any) {
            alert(err.message);
        }
    }

    return (
        <div className="BookList">
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Summary</th>
                        <th>Genre</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    {books.map(b =>
                        <tr key={b.bookId}>
                            <td>{b.bookName}</td>
                            <td>{b.summary}</td>
                            <td>{b.genreName}</td>
                            <td>{b.price}</td>
                            <td>{b.stock}</td>
                            <td>
                                <button onClick={() => { deleteBook(b.bookId) }}>❌</button>
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    );
}

export default BookList;
