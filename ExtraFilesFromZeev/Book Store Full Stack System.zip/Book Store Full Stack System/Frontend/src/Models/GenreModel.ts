class GenreModel {
    public genreId?: number;
    public genreName?: string;
}

export default GenreModel;
