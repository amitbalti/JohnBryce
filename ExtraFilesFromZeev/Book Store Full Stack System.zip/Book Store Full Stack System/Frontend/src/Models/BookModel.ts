class BookModel {

    public bookId?: number;
    public bookName?: string;
    public summary?: string;
    public genreId?: number;
    public price?: number;
    public stock?: number;
    public genreName?: string; // This will be needed on the frontend.

}

export default BookModel;