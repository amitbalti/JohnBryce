import { OkPacket } from "mysql";
import dal from "../2-utils/dal";
import BookModel from "../4-models/book-model";
import GenreModel from "../4-models/genre-model";

async function getAllGenres(): Promise<GenreModel[]> {
    const sql = "SELECT * FROM genres";
    const genres = await dal.execute(sql);
    return genres;
}

async function getAllBooks(): Promise<BookModel[]> {
    const sql = `SELECT books.*, genreName
                 FROM books JOIN genres
                 ON books.genreId = genres.genreId`;
    const books = await dal.execute(sql);
    return books;
}

async function addBook(book: BookModel): Promise<BookModel> {
    const sql = `INSERT INTO books VALUES(
        DEFAULT,
        '${book.bookName}',
        '${book.summary}',
        ${book.genreId},
        ${book.price},
        ${book.stock}
    )`;
    const result: OkPacket = await dal.execute(sql);
    book.bookId = result.insertId;
    return book;
}

async function deleteBook(bookId: number): Promise<void> {
    const sql = `DELETE FROM books WHERE bookId = ${bookId}`;
    const result: OkPacket = await dal.execute(sql);
}

export default {
    getAllGenres,
    getAllBooks,
    addBook,
    deleteBook
};
